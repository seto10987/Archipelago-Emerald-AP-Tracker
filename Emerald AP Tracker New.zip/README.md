# Emerald AP Tracker

Archipelago Pokémon Emerald tracker pack for [PopTracker](https://github.com/black-sliver/PopTracker/) with Autotracking.

PopTracker v0.23.0 or higher is recommended.

![Screenshot of the pack](images/preview.png)